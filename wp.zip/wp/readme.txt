# SecurityFin

**Contributors:** SecurityFin Team  
**Tags:** security, firewall, malware, brute force, login protection, antivirus  
**Requires at least:** 5.0  
**Tested up to:** 6.7  
**Requires PHP:** 7.4  
**Stable tag:** 1.0.0  
**License:** GPLv2 or later  
**License URI:** https://www.gnu.org/licenses/gpl-2.0.html  

SecurityFin is a powerful WordPress security plugin designed to protect your website from common threats such as brute-force attacks, malware injections, file modifications, and unauthorized access. With AI-assisted protection and real-time scanning, SecurityFin ensures your site stays safe and stable at all times.

---

## 🛡️ Features

- **Advanced Firewall Protection**  
  Blocks malicious IPs, bots, and suspicious requests in real-time.

- **Malware Scanner**  
  Automatically scans core files, themes, and plugins for any changes or infections.

- **Login Protection**  
  Prevents brute-force attacks and supports two-factor authentication (2FA).

- **File Integrity Monitoring**  
  Detects unauthorized file changes and alerts you immediately.

- **AI Behavior Analysis**  
  Uses machine learning to detect unusual activities and prevent zero-day threats.

- **Security Reports**  
  Generates detailed daily and weekly reports on your site’s security status.

---

## 🚀 Installation

1. Download the `securityfin.zip` file from your WordPress admin or from the official website.  
2. Go to **Plugins → Add New → Upload Plugin**.  
3. Upload the ZIP file and click **Install Now**.  
4. Once installed, click **Activate Plugin**.  
5. Navigate to **SecurityFin → Dashboard** to start configuring your settings.

---

## ⚙️ Configuration

After activation, visit the **SecurityFin Settings** page to customize:
- Firewall sensitivity levels  
- Email notification preferences  
- Auto-scan schedule  
- IP blacklist/whitelist  
- API key setup for AI Protection (optional)

---

## 📊 Logs & Reports

SecurityFin automatically creates logs under:

/wp-content/plugins/securityfin/logs/

You can view daily activity, blocked IPs, and scan summaries directly from the WordPress dashboard.

---

## 🧠 AI Protection (Optional)

Enable the **AI Protection** module to let SecurityFin analyze user behavior and server patterns in real time.  
This feature requires a valid API key provided by the SecurityFin service.

---

## 🔄 Automatic Updates

SecurityFin supports automatic background updates to ensure your site always runs the latest, most secure version.

---

## 🧩 File Structure

securityfin/ │ ├── admin/ │   ├── dashboard.php │   ├── settings.php │   └── reports.php │ ├── includes/ │   ├── firewall.php │   ├── malware-scanner.php │   ├── login-protection.php │   └── ai-protection.php │ ├── logs/ │ ├── assets/ │   ├── css/ │   └── js/ │ ├── securityfin.php ├── uninstall.php └── readme.txt

---

## 🧰 Changelog

### 1.0.0
- Initial release.  
- Added firewall, malware scanner, login protection, and AI detection.  

---

## 🧑‍💻 Support

If you encounter issues or need help, please visit our official support page:  
[https://securityfin.com/support](https://securityfin.com/support)

---

## ⚖️ License

This plugin is licensed under the [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html).

© 2025 SecurityFin Team. All rights reserved.