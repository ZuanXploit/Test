<?php echo 'Silence is Golden :)';
echo 'Telegram : VectorShield';

?>